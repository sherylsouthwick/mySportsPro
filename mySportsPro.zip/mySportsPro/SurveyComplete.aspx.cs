﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class SurveyComplete : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // Hide text box of survey results.
        txtData.Visible = false;

        // Assign survey results to variables.
        bool contact = (bool)Session["Contact"];
        int custID = (int)Session["CustomerID"];
        int inciID = (int)Session["IncidentID"];
        int response_time = (int)Session["ResponseTime"];
        int tech_efficiency = (int)Session["TechEfficiency"];
        int resolution = (int)Session["Resolution"];
        string comments = (string)Session["Comments"];
        string contact_by = (string)Session["ContactBy"];

        // If contact me checkbox is not checked, hide confirmation message.
        if (contact == false)
        {
            lblContactYou.Visible = false;
        }
        // If contact me box is  checked, display confirmation message.
        else
        {
            lblContactYou.Visible = true;
        }
        // Compile string message with all survey results variables, to be displayed
        // in txtData text box.
        string message =
            "Survey information\n" +
            "    Customer ID: " + custID + "\n" +
            "    Incident ID: " + inciID + "\n" +
            "    Response Time: " + response_time + "\n" +
            "    Tech Efficiency: " + tech_efficiency + "\n" +
            "    Resolution: " + resolution + "\n" +
            "    Contact?: " + contact + "\n" +
            "    Contact method: " + contact_by + "\n" +
            "    Comments: " + "\n" + comments;

        // Display survey results data.
        txtData.Text = message;

    }
    // Survey results textbox becomes visible when View button is selected.
    protected void btnViewData_Click(object sender, EventArgs e)
    {
        txtData.Visible = true;
    }
}