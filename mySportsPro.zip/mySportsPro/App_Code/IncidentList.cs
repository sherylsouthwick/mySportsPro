﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for IncidentList
/// </summary>
public class IncidentList
{
    // Internal list of incidents and the constructor that instantiates it.
    private List<Incident> eachIncident;
    public IncidentList()
    {
        eachIncident = new List<Incident>();
    }
    // Read-only property that returns the number of items in the internal list.
    public int Count
    {
        get { return eachIncident.Count; }
    }
    // Indexers that locate contacts in the internal list by index or incident ID.
    public Incident this[int index]
    {
        get { return eachIncident[index]; }
        set { eachIncident[index] = value; }
    }
    public Incident this[string id]
    {
        get
        {
            foreach (Incident c in eachIncident)
                if (c.IncidentID.ToString() == id) return c;
            return null;
        }
    }
    // Static method to get the contact object from session state.
    public static IncidentList GetIncidents()
    {
        IncidentList incident = (IncidentList)HttpContext.Current.Session["Incident"];
        if (incident == null)
            HttpContext.Current.Session["Incident"] = new IncidentList();
        return (IncidentList)HttpContext.Current.Session["Incident"];
    }

    // Method to add selected Incident to IncidentList.
    public void AddItem(Incident anincident)
    {
        eachIncident.Add(anincident);
    }
}