﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Customer
/// </summary>
public class Customer 
{
    public Customer() { }

    public string CustomerID { get; set; }
    public string Name { get; set; }
    public string StreetAddress { get; set; }
    public string CityStateZip { get; set; }
    public string PhoneNumber { get; set; }
    public string Email { get; set; }

    public string ContactDisplay()
    {
        return Name + ": " + PhoneNumber + "; " + Email;
    }
}