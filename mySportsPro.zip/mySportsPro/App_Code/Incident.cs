﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Incident
/// </summary>
public class Incident
{
    private Incident displayString;
    private Incident incident;

    public Incident() { }

    public Incident(Incident displayString, Incident incident)
    {
        this.displayString = displayString;
        this.incident = incident;
    }

    public string CustomerID { get; set; }
    public string IncidentID { get; set; }
    public string ProductCode { get; set; }
    public string TechID { get; set; }
    public string DateOpened { get; set; }
    public string DateClosed { get; set; }
    public string Title { get; set; }
    public string Description { get; set; }

    public string IncidentDisplay()
    {
        return "Incident for product " + ProductCode + " closed " +
            DateClosed + " (" + Title + ")";
    }
    public string IncidentsDisplay()
    {
        return "Incident for product " + ProductCode + " closed " +
            DateClosed + " (" + Title + ")";
    }
}
