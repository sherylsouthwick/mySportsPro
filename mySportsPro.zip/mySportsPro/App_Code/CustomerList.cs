﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for CustomerList
/// </summary>
public class CustomerList
{
    // Internal list of contacts and the constructor that instantiates it.
    private List<Customer> eachContact;
    public CustomerList()
    {
        eachContact = new List<Customer>();
    }
    // Read-only property that returns the number of items in the internal list.
    public int Count
    {
        get { return eachContact.Count; }
    }
    // Indexers that locate contacts in the internal list by index or customer ID.
    public Customer this[int index]
    {
        get { return eachContact[index]; }
        set { eachContact[index] = value; }
    }
    public Customer this[string id]
    {
        get
        {
            foreach (Customer c in eachContact)
                if (c.CustomerID == id) return c;
            return null;
        }
    }
    // Static method to get the contact object from session state.
    public static CustomerList GetCustomers()
    {
        CustomerList contact = (CustomerList)HttpContext.Current.Session["Contact"];
        if (contact == null)
            HttpContext.Current.Session["Contact"] = new CustomerList();
        return (CustomerList)HttpContext.Current.Session["Contact"];
    }

    // Method to add selected customer to CustomerList.
    public void AddItem(Customer Customer)
    {
        eachContact.Add(Customer);
    }

    // Method to remove selected customer from CustomerList.
    public void RemoveAt(int index)
    {
        eachContact.RemoveAt(index);
    }

    // Method to remove all customers from CustomerList.
    public void Clear()
    {
        eachContact.Clear();
    }
}