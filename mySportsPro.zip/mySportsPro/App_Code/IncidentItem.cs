﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for IncidentItem
/// </summary>
public class IncidentItem
{
    private IncidentItem displayString;
    private IncidentItem incident;

    public IncidentItem() { }

    public IncidentItem(IncidentItem displayString, IncidentItem incident)
    {
        this.displayString = displayString;
        this.incident = incident;
    }
}