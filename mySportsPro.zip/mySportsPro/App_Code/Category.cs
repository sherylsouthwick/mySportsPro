﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

public class Category
{
    public string CustomerID { get; set; }
    public string IncidentID { get; set; }
    public string ProductCode { get; set; }
    public string TechID { get; set; }
    public string DateOpened { get; set; }
    public string DateClosed { get; set; }
    public string Title { get; set; }
    public string Description { get; set; }

    public Category()
    {
    }
}

