﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.ComponentModel;

[DataObject(true)]
public static class CustomerDB
{
    [DataObjectMethod(DataObjectMethodType.Select)]
    public static IEnumerable GetCustomersWithIncidents()
    {
        SqlConnection con = new SqlConnection(GetConnectionString());
        string sel = "SELECT CustomerID, Name "
            + "FROM Customers "
            + "WHERE CustomerID IN "
            + "(SELECT DISTINCT CustomerID FROM Incidents "
            + "WHERE TechID IS NOT NULL) "
            + "ORDER BY Name";
        SqlCommand cmd = new SqlCommand(sel, con);
        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        return dr;
    }

    private static string GetConnectionString()
    {
        return ConfigurationManager.ConnectionStrings
            ["ConnectionString"].ConnectionString;
    }
}

