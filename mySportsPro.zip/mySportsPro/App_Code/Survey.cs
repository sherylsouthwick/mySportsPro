﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Survey
/// </summary>
public class Survey
{

    public int CustomerID { get; set; }
    public int IncidentID { get; set; }
    public int ResponseTime { get; set; }
    public int TechEfficiency { get; set; }
    public int Resolution { get; set; }
    public string Comments { get; set; }
    public bool Contact { get; set; }
    public string ContactBy { get; set; }

    public string Message()
    {
        string message =
            "Survey information\n" +
            "    Customer ID: " + CustomerID;/* + "\n" +
            "    Incident ID: " + IncidentID + "\n" +
            "    Response Time: " + ResponseTime + "\n" +
            "    Tech Efficiency: " + TechEfficiency + "\n" +
            "    Resolution: " + Resolution + "\n" +
            "    Comments: " + Comments + "\n" +
            "    Contact?: " + Contact + "\n" +
            "    Contact method: " + ContactBy + "\n";*/
        return message;
    }
}
