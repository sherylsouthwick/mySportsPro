﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.ComponentModel;

[DataObject(true)]

public static class IncidentDB
{
    /*[DataObjectMethod(DataObjectMethodType.Select)]
    public static List<Category> GetCustomerIncidents(int CustomerID)
    {
        List<Category> categoryList = new List<Category>();
        string sel = "SELECT IncidentID, ProductCode, DateOpened, "
            + "DateClosed, Title, Description "
            + "FROM Incidents "
            + "WHERE (Incidents.CustomerID = @CustomerID) "
            + "ORDER BY Incidents.DateOpened";
        using (SqlConnection con = new SqlConnection(GetConnectionString()))
        {
            using (SqlCommand cmd = new SqlCommand(sel, con))
            {
                cmd.Parameters.AddWithValue("CustomerID", CustomerID);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                Category category;
                while (dr.Read())
                {
                    category = new Category();
                    category.IncidentID = dr["IncidentID"].ToString();
                    category.ProductCode = dr["ProductCode"].ToString();
                    category.DateOpened = dr["DateOpened"].ToString();
                    category.DateClosed = DateTime.Parse(dr["DateClosed"].ToString("MM/dd/yyyy"));
                    category.Title = dr["Title"].ToString();
                    category.Description = dr["Description"].ToString();
                    categoryList.Add(category);
                }
                dr.Close();
            }
        }
        return categoryList;
    }*/

    [DataObjectMethod(DataObjectMethodType.Select)]
    public static IEnumerable GetCustomerIncidents(int CustomerID)
    {
        SqlConnection con = new SqlConnection(GetConnectionString());
        string sel = "SELECT IncidentID, ProductCode, DateOpened, "
            + "DateClosed, Title, Description "
            + "FROM Incidents "
            + "WHERE (Incidents.CustomerID = @CustomerID) "
            + "ORDER BY Incidents.DateOpened";
        SqlCommand cmd = new SqlCommand(sel, con);
        cmd.Parameters.AddWithValue("CustomerID", CustomerID);
        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        return dr;
    }

    [DataObjectMethod(DataObjectMethodType.Select)]
    public static IEnumerable GetOpenTechIncidents(int TechID)
    {
        SqlConnection con = new SqlConnection(GetConnectionString());
        string sel = "SELECT Incidents.IncidentID, Incidents.DateOpened, "
            + "Products.Name AS prodname, Customers.Name AS custname "
            + "FROM Incidents "
            + "INNER JOIN Technicians "
            + "ON Incidents.TechID = Technicians.TechID "
            + "INNER JOIN Products "
            + "ON Incidents.ProductCode = Products.ProductCode "
            + "INNER JOIN Customers "
            + "ON Incidents.CustomerID = Customers.CustomerID "
            + "WHERE (Incidents.TechID = @TechID) "
            + "AND (Incidents.DateClosed IS NULL) "
            + "ORDER BY Incidents.DateOpened";
        SqlCommand cmd = new SqlCommand(sel, con);
        cmd.Parameters.AddWithValue("TechID", TechID);
        con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        return dr;
    }

     private static string GetConnectionString()
    {
        return ConfigurationManager.ConnectionStrings
            ["ConnectionString"].ConnectionString;
    }

    [DataObjectMethod(DataObjectMethodType.Update)]
    public static int UpdateIncident(Category original_Incident,
        Category Incident)
    {
        int updateCount = 0;
        string up = "UPDATE Incidents "
            + "SET DateClosed = @DateClosed, "
            + "Description = @Description "
            + "WHERE IncidentID = @original_IncidentID "
            + "AND DateClosed = @original_DateClosed "
            + "AND Description = @original_Description";

        using (SqlConnection con = new SqlConnection(GetConnectionString()))
        {
            using (SqlCommand cmd = new SqlCommand(up, con))
            {
                cmd.Parameters.AddWithValue("DateClosed", Incident.DateClosed);
                cmd.Parameters.AddWithValue("Description", Incident.Description);
                string newdate = (Convert.ToDateTime("01/01/0001 12:00:00 AM")).ToString();
                if (Incident.DateClosed == newdate) cmd.Parameters.AddWithValue("DateClosed", DBNull.Value);
                else cmd.Parameters.AddWithValue("DateClosed", Incident.DateClosed);
                cmd.Parameters.AddWithValue("original_Description",
                    original_Incident.Description);
                cmd.Parameters.AddWithValue("original_IncidentID",
                    original_Incident.IncidentID);
                con.Open();
                updateCount = cmd.ExecuteNonQuery();
                con.Close();
            }
        }
        return updateCount;
    }
}