﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class CustomerDisplay : System.Web.UI.Page
{
    private Customer selectedCustomer; 
        
    protected void Page_Load(object sender, EventArgs e)
    {
        // Bind dropdown on first load; get and show Customer data on every load.        
        if (!IsPostBack)
            ddlCustomerName.DataBind();
        // Assign location for each element.
        selectedCustomer = this.GetSelectedCustomer();
        lblStreetAddress.Text = selectedCustomer.StreetAddress;
        lblCityStateZip.Text = selectedCustomer.CityStateZip;
        lblPhoneNumber.Text = selectedCustomer.PhoneNumber;
        lblEmail.Text = selectedCustomer.Email;
    }

    private Customer GetSelectedCustomer()
    {
        // Get row from SqlDataSource based on value in dropdownlist.
        DataView customersTable = (DataView)
            SqlDataSource1.Select(DataSourceSelectArguments.Empty);
        customersTable.RowFilter =
            "CustomerID = '" + ddlCustomerName.SelectedValue + "'";
        DataRowView row = (DataRowView)customersTable[0];

        // Create a new Customer object and load with data from row.
        Customer cust = new Customer();
        cust.CustomerID = row["CustomerID"].ToString();
        cust.Name = row["Name"].ToString();
        cust.StreetAddress = row["Address"].ToString();
        cust.CityStateZip = row["City"].ToString() + ", " + row["State"].ToString() + " " 
            + row["ZipCode"].ToString();
        cust.PhoneNumber = row["Phone"].ToString();
        cust.Email = row["Email"].ToString();
        return cust;
    }

    protected void btnAddToContactList_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            // Get contact from session and selected item from contact.
            CustomerList contact = CustomerList.GetCustomers();
            Customer ContactName = contact[selectedCustomer.CustomerID];
          
            // If selected Customer isn’t in contact list, add it; otherwise, display error message.
            if (ContactName == null)
            {
                contact.AddItem(selectedCustomer);
                Response.Redirect("~/ContactDisplay.aspx", false);
            }
            else
            {
                lblErrorMessage.Text = "This customer is already in the Contact List.";
            }
            
        }

    }
}