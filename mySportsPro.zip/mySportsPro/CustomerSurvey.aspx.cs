﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class CustomerSurvey : System.Web.UI.Page
{
    private Survey survey;
    private Incident selectedIncident;
    protected void Page_Load(object sender, EventArgs e)
    {
        Session.Remove("Incident");
        // Bind CustomerID textbox on first load; get Incident data on every load.        
        if (!IsPostBack)  
        {
            survey = (Survey)Session["Survey"];
            selectedIncident = (Incident)Session["Incident"];
            textbxCustomerID.DataBind();
        }
    }
    private Incident GetSelectedIncidents(int i)
    {   // Execute if table data by customer ID is not null.
        try
        {   // Assign customer ID variable.
            int custid = Convert.ToInt32(textbxCustomerID.Text);

            // Get row from SqlDataSource based on value in listbox.
            DataView incidentsTable = (DataView)
            SqlDataSource1.Select(DataSourceSelectArguments.Empty);
            incidentsTable.RowFilter = "CustomerID = '" + custid + "'";
            DataRowView row = (DataRowView)incidentsTable[i];

            // Create a new Incident object and load with data from row.
            Incident inci = new Incident();
            inci.IncidentID = row["IncidentID"].ToString();
            inci.CustomerID = row["CustomerID"].ToString();
            inci.TechID = row["TechID"].ToString();
            inci.ProductCode = row["ProductCode"].ToString();
            inci.DateOpened = row["DateOpened"].ToString();
            inci.DateClosed = row["DateClosed"].ToString();
            inci.Title = row["Title"].ToString();
            return inci;
        }
        //  Return null value if table data by customer ID is null.
        catch
        {
            return null;
        }
    }
    protected void btnGetIncidents_Click(object sender, EventArgs e)
    {
        // Disable all controls except Customer ID textbox and Get Incidents button.
        // Disable and clear listbxIncidents.
        DisableControls();
        listbxIncidents.Enabled = false;
        listbxIncidents.Items.Clear();

        // Test whether customer ID is an integer, and is in range, if true assign integer custID.
        int custID; bool is_a_valid_ID; bool is_a_number = int.TryParse(textbxCustomerID.Text, out custID);
        if (custID > 999 & custID < 2000)
        {
            is_a_valid_ID = true; 
        }
        else
            is_a_valid_ID = false;

        // If any incidents are listed, and ID is a valid customer ID, show incidents 
        // and enable listbox. (Otherwise, do nothing. Error will be handled with aspx code.)
        if (listbxIncidents.Items.Count > -1 & is_a_valid_ID == true) 
        {
            listbxIncidents.Items.Add("--Select an incident--");
            listbxIncidents.Enabled = true;

            // Get incidents from session for corresponding Incident ID.
            for (int i = 0; i < 2; i++)
            {
                //IncidentDisplay();
                DisplayClosedIncidents(i);
            }
        }

    }
    // Enable all controls when an incident is selected.
    private void EnableControls()
    {
        rblResponseTime.Enabled = true;
        rblTechEfficiency.Enabled = true;
        rblProblemResolution.Enabled = true;
        bxComments.Enabled = true;
        cblContactMe.Enabled = true;
        btnSubmit.Enabled = true;
        rblContactVia.Enabled = true;

    }
    // Disable selected controls when customer ID is changed.
    private void DisableControls()
    {
        lblNoIncidents.Text = "";
        rblResponseTime.Enabled = false;
        rblTechEfficiency.Enabled = false;
        rblProblemResolution.Enabled = false;
        bxComments.Enabled = false;
        cblContactMe.Enabled = false;
        rblContactVia.Enabled = false;
        btnSubmit.Enabled = false;
    }
    // Fill listbox with incidents.
    private void DisplayClosedIncidents(int i)
    {
        // Assign location for each element.
        selectedIncident = this.GetSelectedIncidents(i);
        if (selectedIncident!= null)
        {   
            // enable listbox and move focus to listbox.
            //Get incidents that match customerID.
            listbxIncidents.Enabled = true; this.listbxIncidents.Focus();
            IncidentList incidentline = IncidentList.GetIncidents();
            Incident Incident = incidentline[selectedIncident.IncidentID];

            //Add selected incidents to list.
            incidentline.AddItem(selectedIncident);

            // Fill listbox with text and values of selected incidents.
            listbxIncidents.Items.Add(new ListItem(selectedIncident.
                IncidentDisplay(), selectedIncident.IncidentID.ToString()));
        }
        else
        {
            // If there are no incidents, clear listbox and display message.
            if (selectedIncident == null & i==0 )
            {
                string displayString = "    Customer ID has no closed incidents.";
                listbxIncidents.Enabled = false;
                listbxIncidents.Items.Clear();
                lblNoIncidents.Text= displayString;
            }
        }
    }
    // Button saves survey info input by customer and changes to Survey Complete page.
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        //    Page.Validate;
        if (Page.IsValid)
        {
            // Assign customer input information to survey objects.
            Survey survey = new Survey();
            survey.CustomerID = int.Parse(textbxCustomerID.Text);
            survey.IncidentID = int.Parse(listbxIncidents.SelectedValue);
            survey.ResponseTime = int.Parse(rblResponseTime.SelectedValue);
            survey.TechEfficiency = int.Parse(rblTechEfficiency.SelectedValue);
            survey.Resolution = int.Parse(rblProblemResolution.SelectedValue);
            survey.Comments = bxComments.Text;
            if (cblContactMe.Checked)
            {
                survey.Contact = true;
            }

            else { survey.Contact = false; }
            survey.ContactBy = rblContactVia.SelectedValue;

            // Add survey objects to session.
            Session.Add("CustomerID", survey.CustomerID);
            Session.Add("IncidentID", survey.IncidentID);
            Session.Add("ResponseTime", survey.ResponseTime);
            Session.Add("TechEfficiency", survey.TechEfficiency);
            Session.Add("Resolution", survey.Resolution);
            Session.Add("Comments", survey.Comments);
            Session.Add("ContactBy", survey.ContactBy);
            Session.Add("Contact", survey.Contact);

            // Go to Survey Complete page.
            Response.Redirect("~/SurveyComplete.aspx");
        }
    }
    // If an incident is selected, survey controls are enabled.
    protected void listbxIncidents_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (listbxIncidents.SelectedIndex > 0)
        EnableControls();
    }
    // If contact checkbox is checked or unchecked, contactVia is enabled or disabled.
    protected void cblContactMe_CheckedChanged(object sender, EventArgs e)
    {
        if (!cblContactMe.Checked)
        {
            rblContactVia.Enabled = false;
        }
        else
        {
            rblContactVia.Enabled = true;
        }
    }
}