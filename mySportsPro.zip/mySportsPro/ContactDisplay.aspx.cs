﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class ContactDisplay : System.Web.UI.Page
{
    private CustomerList contact;

    protected void Page_Load(object sender, EventArgs e)
    {
        // Retrieve contact object form session state on every post back.
        contact = CustomerList.GetCustomers();

        // On initial page load, add selected contact to list control.
        if (!IsPostBack)
            this.DisplayContact();
    }

    private void DisplayContact()
    {
        // Remove all current contacts from listbxContact.
        listbxContact.Items.Clear();
        //ContactName item;
        Customer item;

        // Loop through contacts and add each contact's Display value to the control.
        for (int i = 0; i < contact.Count; i++)
        {
            item = contact[i];
            listbxContact.Items.Add(item.ContactDisplay());
        }
    }

    protected void btnEmptyList_Click(object sender, EventArgs e)
    {
        // Clear any contacts from contact list and listbxContact.
        if (contact.Count > 0)
        {
            contact.Clear();
            listbxContact.Items.Clear();
        }
    }

    protected void btnRemoveContact_Click(object sender, EventArgs e)
    {
        // If listbxContact contains contacts and user has selected a contact...
        if (contact.Count > 0)
        {
            if (listbxContact.SelectedIndex > -1)
            {
                // Remove selected contact from listbxContact and re-add contacts.
                contact.RemoveAt(listbxContact.SelectedIndex);
                this.DisplayContact();
            }
            else
            // If no contacts are selected, notify user.
            {
                lblMessage.Text = "Please select the customer you want to remove.";
            }
        }
    }
}
